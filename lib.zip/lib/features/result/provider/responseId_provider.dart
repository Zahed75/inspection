// Add this to your providers file or create a new one
import 'package:flutter_riverpod/flutter_riverpod.dart';

final latestResponseIdProvider = StateProvider<int?>((ref) => null);
